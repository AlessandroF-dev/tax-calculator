package br.com.taxcalculator.taxcalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
